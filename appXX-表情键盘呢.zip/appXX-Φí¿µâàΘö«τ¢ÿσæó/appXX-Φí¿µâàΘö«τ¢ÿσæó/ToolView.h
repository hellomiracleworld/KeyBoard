//
//  ToolView.h
//  appXX-表情键盘呢
//
//  Created by MRBean on 15/8/17.
//  Copyright (c) 2015年 yangbin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTextView.h"
/**
 *  Block封装组件的原则:
 *  1.SDK写给别人用,必须有相关的访问的接口,和别人的自定义代码,不需要暴露的代码写在.m中,.h只留必需的代码
 *  2.使用一个.h文件中的block属性来接收使用者的代码,或者使用一个方法来接收并且存储在延展中的block属性中
 *  3.该接收的block代码块在系统事件(如按钮点击,视图消失,视图出现,网络加载成功或失败等)发生的时候来调用,block需要判空操作
 *  4.如果该组件不是最外层的组件,则需要从外到内提供接口来给该组件提供block代码块,
 *  当事件发生时由最底层的block块来逐层调用外层的block,最终调用最外层(开放组件层)的block块
 *  5.block参数:组件自身事件的一些信息,需要提供给组件的使用者,组件的使用者需要这些信息来写代码
 */

typedef void(^SendBlock)(NSAttributedString *attStr);
//底部按钮的block
typedef void(^BottomBlock)(NSAttributedString *attStr,BottomButtonType buttonType);
@interface ToolView : UIView
/**
 *  设置底部的3个按钮的回调
 *
 *  @param bottomBlock 底部3个按钮的回调
 */

- (void)setTapBottomButtonBlock:(BottomBlock)bBlock;

- (void)setFuncButtonBlock:(FuncButtonBlock)funcBlock;

- (void)setTapSendBlock:(SendBlock)sendBlock;

@end
