//
//  ViewController.m
//  appXX-表情键盘呢
//
//  Created by MRBean on 15/8/17.
//  Copyright (c) 2015年 yangbin. All rights reserved.
//

#import "ViewController.h"
#import "ToolView.h"
#import "Tools.h"
@interface ViewController ()
@property(strong,nonatomic)ToolView *toolView;
@property(strong,nonatomic)UITextView *textView1;
@property(strong,nonatomic)UITextView *textView2;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    __weak typeof(self)weak_self  =self;
    
    _toolView = [[ToolView alloc]init];
    [self.view addSubview:_toolView];
    NSArray *h = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[_toolView]|" options:0 metrics:0 views:NSDictionaryOfVariableBindings(_toolView)];
    NSArray *v = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[_toolView(48)]|" options:0 metrics:0 views:NSDictionaryOfVariableBindings(_toolView)];
    [self.view addConstraints:h];
    [self.view addConstraints:v];
    
    
    _textView1 = [[UITextView alloc]init];
    _textView1.editable = NO;
    _textView1.layer.borderWidth = 1;
    _textView1.text = @"把普通字符串转换为属性字符串:";
    _textView1.layer.borderColor = [UIColor blueColor].CGColor;
    _textView1.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_textView1];
    NSArray *v1 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-64-[_textView1(150)]" options:0 metrics:0 views:NSDictionaryOfVariableBindings(_textView1,_toolView)];
    NSArray *h1 = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[_textView1]|" options:0 metrics:0 views:NSDictionaryOfVariableBindings(_textView1)];
    [self.view addConstraints:h1];
    [self.view addConstraints:v1];
    
    
    
    _textView2 = [[UITextView alloc]init];
    _textView2.backgroundColor = [UIColor colorWithRed:239/255.0 green:239.0/255 blue:239.0/255 alpha:1];
    _textView2.editable = NO;
    _textView2.layer.borderWidth = 1;
    _textView2.text = @"普通字符串:";
    _textView2.layer.borderColor = [UIColor blackColor].CGColor;
    _textView2.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_textView2];
    NSArray *v2 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[_textView1][_textView2][_toolView]" options:0 metrics:0 views:NSDictionaryOfVariableBindings(_textView1,_textView2,_toolView)];
    NSArray *h2 = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[_textView2]|" options:0 metrics:0 views:NSDictionaryOfVariableBindings(_textView2)];
    
    [self.view addConstraints:v2];
    [self.view addConstraints:h2];
    
    
    
    
    
    
    
    //使用toolView需要给他制定block代码
    [_toolView setFuncButtonBlock:^(FuncButtonType buttonIndex) {
        switch (buttonIndex) {
            case FuncButtonTypeCamera:
            {
                NSLog(@"你点击了相机!");
            }
                break;
            case FuncButtonTypePhoto:
            {
                NSLog(@"你点击了相册!");
            }
                break;

            case FuncButtonTypeLocation:
            {
                NSLog(@"你点击了定位!");
            }
                break;

                
                
            default:
                break;
        }
    }];
    
    
    
    [_toolView setTapSendBlock:^(NSAttributedString *attStr) {
        //点击原生键盘上的发送按钮,让attStr在两个textView上显示
        [weak_self configTwoText:attStr];
    }];
    
    
    [_toolView setTapBottomButtonBlock:^(NSAttributedString *attStr, BottomButtonType buttonType) {
        switch (buttonType) {
            case BottomButtonTypeRecently:
                
                break;
            case BottomButtonTypeDefaut:
                break;
            case BottomButtonTypeSend:
            {
                //
                [weak_self configTwoText:attStr];
                
            }
                break;
                
            default:
                break;
        }
    }];

    
    //监听键盘的状态通知,该键盘通知由系统发出,不需要手动发出
    NSNotificationCenter * center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(receiveNoti:) name:UIKeyboardWillChangeFrameNotification object:nil];
    

}

#pragma mark -调整键盘高度
//通知中心回调：当键盘高度将要变化时，此方法被调用
-(void)receiveNoti:(NSNotification *)noti
{
    //获取通知信息
    NSDictionary *dic=[noti userInfo];
    //键盘弹起来所需要的时间
    NSNumber *duration=dic[UIKeyboardAnimationDurationUserInfoKey];
    //曲线
    NSNumber *curve=dic[UIKeyboardAnimationCurveUserInfoKey];
    NSValue *vE=dic[UIKeyboardFrameEndUserInfoKey];//键盘弹起结束后的frame
    CGRect keyBoardFrame = [vE CGRectValue];
    CGFloat height = [[UIScreen mainScreen]bounds].size.height;
    CGRect frame = self.view.frame;
    //改变view的高度,从而让toolView上移
    frame.size.height = height-(height-keyBoardFrame.origin.y);
    //使用动画改变view的frame
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:duration.intValue];
    [UIView setAnimationCurve:curve.intValue];
    self.view.frame = frame;
    [self.view layoutIfNeeded];//重新布局
    [UIView commitAnimations];
    

}

#pragma mark - 配置两个textView上,让其显示对应的文字
- (void)configTwoText:(NSAttributedString*)attStr
{
    __weak typeof(self)weak_self = self;
    //textView2的字符串,是普通的字符串,plainText是网络传输字符串
    NSString *plainText = [Tools attStringToString:attStr];//转换属性字符串为普通字符串
    NSMutableString *mstr1 = [[NSMutableString alloc]initWithString:weak_self.textView2.text];
    [mstr1 appendString:plainText];
    weak_self.textView2.text = mstr1;
    
    //textView1的字符串,是属性字符串,是通过从普通字符串转换而来的
    
    NSAttributedString *attStrNew = [Tools stringToAttributeString:plainText];//模拟收到网络字符串(plainText),转换为属性字符串
    
    NSMutableAttributedString *mattr = [[NSMutableAttributedString alloc]initWithAttributedString:weak_self.textView1.attributedText];
    [mattr appendAttributedString:attStrNew];
    weak_self.textView1.attributedText = mattr;
}

@end
